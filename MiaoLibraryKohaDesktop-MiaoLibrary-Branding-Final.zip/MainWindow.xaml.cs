using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using Microsoft.Web.WebView2.Core;
using Microsoft.Win32;

namespace MiaoLibraryKohaDesktop;

public partial class MainWindow : Window
{
    private const string KohaUrl =
        "https://staff.miaolibrary.in/cgi-bin/koha/mainpage.pl";
    private const string TrustedHost = "staff.miaolibrary.in";

    private string? _normalWindowState;
    private WindowState _savedWindowState;
    private WindowStyle _savedWindowStyle;
    private bool _fullscreen;

    public MainWindow()
    {
        InitializeComponent();
        Loaded += MainWindow_Loaded;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        await InitializeBrowserAsync();
    }

    private async System.Threading.Tasks.Task InitializeBrowserAsync()
    {
        try
        {
            string fixedRuntimePath = Path.Combine(AppContext.BaseDirectory, "FixedRuntime");
            if (!Directory.Exists(fixedRuntimePath))
                throw new DirectoryNotFoundException(
                    "The bundled WebView2 Fixed Version runtime is missing.");

            string userDataPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "MiaoLibraryKohaDesktop", "WebView2");
            Directory.CreateDirectory(userDataPath);

            var environment = await CoreWebView2Environment.CreateAsync(
                fixedRuntimePath, userDataPath);

            await KohaBrowser.EnsureCoreWebView2Async(environment);

            var settings = KohaBrowser.CoreWebView2.Settings;
            settings.AreDevToolsEnabled = false;
            settings.AreDefaultContextMenusEnabled = true;
            settings.IsStatusBarEnabled = false;
            settings.IsZoomControlEnabled = true;
            settings.AreBrowserAcceleratorKeysEnabled = true;

            KohaBrowser.CoreWebView2.NewWindowRequested += CoreWebView2_NewWindowRequested;
            KohaBrowser.CoreWebView2.DownloadStarting += CoreWebView2_DownloadStarting;

            KohaBrowser.Source = new Uri(KohaUrl);
        }
        catch (Exception ex)
        {
            LoadingPanel.Visibility = Visibility.Visible;
            StatusText.Text = "Unable to start Koha: " + ex.Message;
            ConnectionText.Text = "Connection unavailable";
        }
    }

    private static bool IsTrustedUri(string? value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri))
            return false;

        return uri.Scheme == Uri.UriSchemeHttps &&
               string.Equals(uri.Host, TrustedHost, StringComparison.OrdinalIgnoreCase);
    }

    private void KohaBrowser_NavigationStarting(object? sender,
        CoreWebView2NavigationStartingEventArgs e)
    {
        if (!IsTrustedUri(e.Uri))
        {
            e.Cancel = true;
            return;
        }

        LoadingPanel.Visibility = Visibility.Visible;
        StatusText.Text = "Loading Koha...";
        ConnectionText.Text = "Connecting...";
        UpdateNavigationButtons();
    }

    private void KohaBrowser_NavigationCompleted(object? sender,
        CoreWebView2NavigationCompletedEventArgs e)
    {
        LoadingPanel.Visibility = Visibility.Collapsed;
        ConnectionText.Text = e.IsSuccess ? "Connected to Koha" : "Koha connection error";
        PageTitle.Text = KohaBrowser.CoreWebView2.DocumentTitle;
        UpdateNavigationButtons();
    }

    private void CoreWebView2_NewWindowRequested(object? sender,
        CoreWebView2NewWindowRequestedEventArgs e)
    {
        e.Handled = true;
        if (IsTrustedUri(e.Uri))
            KohaBrowser.CoreWebView2.Navigate(e.Uri);
    }

    private void CoreWebView2_DownloadStarting(object? sender,
        CoreWebView2DownloadStartingEventArgs e)
    {
        string downloads = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
            "Downloads");
        Directory.CreateDirectory(downloads);

        string fileName = Path.GetFileName(e.ResultFilePath);
        if (string.IsNullOrWhiteSpace(fileName))
            fileName = "Koha-download";

        e.ResultFilePath = Path.Combine(downloads, fileName);
    }

    private void KohaBrowser_DownloadStarting(object? sender,
        CoreWebView2DownloadStartingEventArgs e) => CoreWebView2_DownloadStarting(sender, e);

    private void Back_Click(object sender, RoutedEventArgs e)
    {
        if (KohaBrowser.CanGoBack) KohaBrowser.GoBack();
    }

    private void Forward_Click(object sender, RoutedEventArgs e)
    {
        if (KohaBrowser.CanGoForward) KohaBrowser.GoForward();
    }

    private void Refresh_Click(object sender, RoutedEventArgs e) =>
        KohaBrowser.Reload();

    private void Home_Click(object sender, RoutedEventArgs e) =>
        KohaBrowser.CoreWebView2?.Navigate(KohaUrl);

    private void ZoomIn_Click(object sender, RoutedEventArgs e) =>
        SetZoom(KohaBrowser.ZoomFactor + 0.1);

    private void ZoomOut_Click(object sender, RoutedEventArgs e) =>
        SetZoom(KohaBrowser.ZoomFactor - 0.1);

    private void ZoomReset_Click(object sender, RoutedEventArgs e) =>
        SetZoom(1.0);

    private void SetZoom(double value)
    {
        value = Math.Max(0.5, Math.Min(2.0, value));
        KohaBrowser.ZoomFactor = value;
        ZoomText.Text = $"{Math.Round(value * 100)}%";
    }

    private void Fullscreen_Click(object sender, RoutedEventArgs e)
    {
        if (!_fullscreen)
        {
            _savedWindowState = WindowState;
            _savedWindowStyle = WindowStyle;
            WindowStyle = WindowStyle.None;
            WindowState = WindowState.Maximized;
            _fullscreen = true;
        }
        else
        {
            WindowStyle = _savedWindowStyle;
            WindowState = _savedWindowState;
            _fullscreen = false;
        }
    }


    private void About_Click(object sender, RoutedEventArgs e)
    {
        var about = new Window
        {
            Title = "About Miao Library — Koha Desktop",
            Width = 520,
            Height = 620,
            MinWidth = 460,
            MinHeight = 540,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Owner = this,
            ResizeMode = ResizeMode.NoResize,
            Background = System.Windows.Media.Brushes.White
        };

        var panel = new System.Windows.Controls.StackPanel
        {
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(32)
        };

        var logo = new System.Windows.Controls.Image
        {
            Source = new System.Windows.Media.Imaging.BitmapImage(
                new Uri(Path.Combine(AppContext.BaseDirectory, "Assets", "MiaoLibraryBrand.png"))),
            Width = 300,
            Height = 300,
            Stretch = System.Windows.Media.Stretch.Uniform,
            HorizontalAlignment = HorizontalAlignment.Center
        };

        var title = new System.Windows.Controls.TextBlock
        {
            Text = "Miao Library",
            FontSize = 30,
            FontWeight = FontWeights.SemiBold,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 18, 0, 4)
        };

        var subtitle = new System.Windows.Controls.TextBlock
        {
            Text = "Koha Desktop",
            FontSize = 20,
            HorizontalAlignment = HorizontalAlignment.Center,
            Foreground = System.Windows.Media.Brushes.DimGray
        };

        var version = new System.Windows.Controls.TextBlock
        {
            Text = "Version 1.0.0",
            FontSize = 14,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 16, 0, 3)
        };

        var builtFor = new System.Windows.Controls.TextBlock
        {
            Text = "Built for Miao Library",
            FontSize = 14,
            HorizontalAlignment = HorizontalAlignment.Center,
            Foreground = System.Windows.Media.Brushes.DimGray
        };

        var close = new System.Windows.Controls.Button
        {
            Content = "Close",
            Width = 100,
            Margin = new Thickness(0, 22, 0, 0),
            HorizontalAlignment = HorizontalAlignment.Center,
            Padding = new Thickness(10, 5, 10, 5)
        };
        close.Click += (_, _) => about.Close();

        panel.Children.Add(logo);
        panel.Children.Add(title);
        panel.Children.Add(subtitle);
        panel.Children.Add(version);
        panel.Children.Add(builtFor);
        panel.Children.Add(close);

        about.Content = panel;
        about.ShowDialog();
    }

    private void Logout_Click(object sender, RoutedEventArgs e)
    {
        // Koha owns authentication. Navigate to its logout endpoint so the
        // actual Koha staff session is terminated rather than maintaining a
        // separate desktop-client credential store.
        KohaBrowser.CoreWebView2?.Navigate(
            "https://staff.miaolibrary.in/cgi-bin/koha/mainpage.pl?logout.x=1");
    }

    private async void Retry_Click(object sender, RoutedEventArgs e)
    {
        LoadingPanel.Visibility = Visibility.Visible;
        StatusText.Text = "Retrying...";
        if (KohaBrowser.CoreWebView2 == null)
            await InitializeBrowserAsync();
        else
            KohaBrowser.CoreWebView2.Navigate(KohaUrl);
    }

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.R)
            KohaBrowser.Reload();
        else if (Keyboard.Modifiers == ModifierKeys.Alt && e.Key == Key.Left)
            Back_Click(sender, e);
        else if (Keyboard.Modifiers == ModifierKeys.Alt && e.Key == Key.Right)
            Forward_Click(sender, e);
        else if (e.Key == Key.F11)
            Fullscreen_Click(sender, e);
        else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.Add)
            ZoomIn_Click(sender, e);
        else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.Subtract)
            ZoomOut_Click(sender, e);
    }

    private void UpdateNavigationButtons()
    {
        if (KohaBrowser.CoreWebView2 == null) return;
        BackButton.IsEnabled = KohaBrowser.CoreWebView2.CanGoBack;
        ForwardButton.IsEnabled = KohaBrowser.CoreWebView2.CanGoForward;
    }

    protected override void OnClosed(EventArgs e)
    {
        try { KohaBrowser.Dispose(); } catch { }
        base.OnClosed(e);
    }
}
