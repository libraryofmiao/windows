$ErrorActionPreference = "Stop"

if (-not (Test-Path ".\Assets\MiaoLibrary.ico")) {
    throw "MiaoLibrary.ico is missing from Assets."
}

dotnet restore .\MiaoLibraryKohaDesktop.csproj
dotnet publish .\MiaoLibraryKohaDesktop.csproj `
  -c Release -r win-x64 --self-contained true `
  -p:PublishTrimmed=false `
  -o .\publish

if (-not (Test-Path ".\publish\FixedRuntime\msedgewebview2.exe")) {
    throw "FixedRuntime is missing. Download Microsoft's WebView2 Fixed Version x64 package, extract it into .\FixedRuntime, then rerun this script."
}

& iscc.exe .\installer\MiaoLibraryKoha.iss
