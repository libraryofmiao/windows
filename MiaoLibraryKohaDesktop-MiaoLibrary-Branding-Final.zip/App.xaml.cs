using System.Windows;

namespace MiaoLibraryKohaDesktop;

public partial class App : Application
{
}
