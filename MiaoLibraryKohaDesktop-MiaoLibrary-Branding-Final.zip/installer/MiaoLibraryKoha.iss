; Miao Library Koha Desktop - standalone installer
#define MyAppName "Miao Library — Koha Desktop"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Miao Library"
#define MyAppIcon "..\Assets\MiaoLibrary.ico"
#define MyAppExeName "MiaoLibraryKohaDesktop.exe"

[Setup]
AppId={{D7BEEA53-9B2D-4F91-AF5D-7E0D0F7A1D35}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Miao Library Koha
DefaultGroupName=Miao Library Koha
OutputDir=..\artifacts
OutputBaseFilename=MiaoLibraryKohaSetup
Compression=lzma2
SolidCompression=yes
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
WizardStyle=modern
UninstallDisplayIcon={app}\MiaoLibrary.ico

[Files]
Source: "..\publish\*"; DestDir: "{app}"; Flags: recursesubdirs ignoreversion
Source: "{#MyAppIcon}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\Miao Library Koha Desktop"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\MiaoLibrary.ico"
Name: "{autodesktop}\Miao Library Koha"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\MiaoLibrary.ico"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch Miao Library Koha"; Flags: nowait postinstall skipifsilent
