# Miao Library Koha Desktop

Standalone Windows desktop client for the actual Koha staff interface.

## Production Koha URL

`https://staff.miaolibrary.in/cgi-bin/koha/mainpage.pl`

The application embeds the real Koha staff web interface, so Koha remains the system of record and the client uses the existing Koha resources, permissions, workflows and data.

## Standalone deployment

The application is built as:

- .NET 8 WPF, self-contained `win-x64`
- WebView2 Fixed Version runtime bundled inside the application
- One Inno Setup installer
- No separate .NET Runtime installation
- No separate WebView2 Runtime installation
- No browser installation required for the client

Microsoft documents that the WebView2 Fixed Version runtime can be packaged with an application and selected through `CoreWebView2Environment.CreateAsync` using `browserExecutableFolder`. The Fixed Version package is large (Microsoft documents it as over 250 MB), so the final installer will be correspondingly large.

## Required build asset

Before building, obtain the current x64 WebView2 Fixed Version package from Microsoft's official WebView2 download page and extract it into:

`FixedRuntime\`

The folder must contain `msedgewebview2.exe` directly inside `FixedRuntime`.

Do not substitute a third-party WebView2 runtime.

## Build on Windows

Run:

`powershell -ExecutionPolicy Bypass -File .\build-windows.ps1`

Or use the included GitHub Actions workflow after adding the Microsoft Fixed Version runtime under `FixedRuntime/`.

## Important

The actual Windows EXE/installer must be compiled on a Windows build environment. This source package is prepared for that build; it has not been falsely represented as an already-compiled Windows EXE.


## Desktop functions included

- Native Back / Forward / Refresh / Koha Home toolbar
- Zoom out / reset / zoom in
- Full-screen mode with F11
- Retry/reconnect screen
- Trusted HTTPS host restriction
- Native Downloads folder routing
- Koha session logout action
- Connection status and page title
- Keyboard shortcuts: Ctrl+R, Alt+Left/Right, F11, Ctrl+Plus/Minus
- Native desktop window and status bar


## Miao Library branding

The desktop shell is branded as **Miao Library — Koha Desktop**. The same Miao Library mark is used for the Windows application icon, desktop shortcut, installer shortcut, and installer/uninstall identity. The About dialog identifies the application as built for Miao Library.

`Assets/MiaoLibraryBrand.png` and `Assets/MiaoLibrary.ico` use the official Miao Library logo supplied for this project.

The official logo is displayed large in the About window and at an appropriate smaller size in the desktop toolbar and Windows icon assets.
